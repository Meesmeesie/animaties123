<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
<head>
  <title>Animaties123!!</title>
</head>

<body>

<!-- Navigatie-menu -->
<ul class="navbar">
  <li><a href="Animaties.html">Animaties!!</a>

<!-- Hoofdtekst -->
<h1>Welkom bij: Animaties123</h1>

<p>Mooi toch?

<p>&hellip;

<p>Klik op Animaties!!! Voor de animaties!!.

<!-- Onderteken en dateer de pagina, wees beleefd! -->
<address>Gemaakt op: 26 mei 2019<br>
  door: Mees.</address>

</body>
</html>

