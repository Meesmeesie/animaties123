# Changelog

- 10.02.2019
  - fixed deprecated warnings for newer nodejs versions
